const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(PUBLIC, { extensions: ["html"] }));

app.get("/api/status", (_req, res) => {
  res.json({
    status: "active",
    platform: "NOVA Social",
    version: "3.0.0",
    serverTime: new Date().toISOString()
  });
});

app.get("/api/weather", async (req, res) => {
  const latitude = Number(req.query.lat ?? 33.5731);
  const longitude = Number(req.query.lon ?? -7.5898);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    return res.status(400).json({ error: "Invalid coordinates" });
  }
  try {
    const url = new URL("https://api.open-meteo.com/v1/forecast");
    url.searchParams.set("latitude", latitude);
    url.searchParams.set("longitude", longitude);
    url.searchParams.set("current", "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m");
    url.searchParams.set("timezone", "auto");
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Weather provider returned ${response.status}`);
    res.json(await response.json());
  } catch (error) {
    res.status(502).json({ error: "Weather provider unavailable" });
  }
});

app.get("/api/market", async (_req, res) => {
  try {
    const url = new URL("https://api.coingecko.com/api/v3/simple/price");
    url.searchParams.set("ids", "bitcoin,ethereum,solana");
    url.searchParams.set("vs_currencies", "usd");
    url.searchParams.set("include_24hr_change", "true");
    const response = await fetch(url, { headers: { accept: "application/json" } });
    if (!response.ok) throw new Error(`Market provider returned ${response.status}`);
    res.json(await response.json());
  } catch (error) {
    res.status(502).json({ error: "Market provider unavailable" });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(PUBLIC, "index.html"));
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`\nNOVA Social 3.0`);
  console.log(`Local: http://localhost:${PORT}`);
  console.log(`Press Ctrl+C to stop.\n`);
});
